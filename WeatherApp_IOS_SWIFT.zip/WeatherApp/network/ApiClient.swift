//
//  ApiClient.swift
//  WeatherApp
//
//  Created by Shubhamjit on 26/08/26.
//

import Foundation

final class ApiClient {
    
    // Shared singleton instance for easy app-wide reuse
    static let shared = ApiClient()
    
    private init() {}
    
    /// Generic GET function to fetch and decode JSON from any URL
    func get<T:Decodable>(urlString: String, headers: [String: String] = [:]) async -> ApiState<T> {
        // 1. Validate URL
        guard let url = URL(string: urlString) else {
            return .Falure(msg: ErrorCodes.URL_INVALID)
        }
        
        var request = URLRequest(url: url)
        headers.forEach { request.setValue($1, forHTTPHeaderField: $0) }
        
        do {
            // 2. Perform Network Request
            let (data, response) = try await URLSession.shared.data(for: request)
            
            // 3. Check HTTP Response Code
            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                return .Falure(msg: ErrorCodes.UNKNOWN_ERROR)
            }
            
            // 4. Decode JSON to the target Decodable type
            let decodedData = try JSONDecoder().decode(T.self, from: data)
            return .Success(data: decodedData)
            
        } catch is DecodingError {
            // Specific catch for JSON parsing failures
            return .Falure(msg: ErrorCodes.UNKNOWN_ERROR)
        } catch {
            // Catch network timeouts, offline mode, etc.
            return .Falure(msg: ErrorCodes.NO_INTERNET)
        }
    }
    
    /// Generic POST function to send an Encodable body and decode JSON response
    func post<T: Decodable, B: Encodable>(urlString: String, body: B, headers: [String: String] = [:]) async -> ApiState<T> {
        guard let url = URL(string: urlString) else {
            return .Falure(msg: ErrorCodes.URL_INVALID)
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        headers.forEach { request.setValue($1, forHTTPHeaderField: $0) }
        
        do {
            request.httpBody = try JSONEncoder().encode(body)
            
            let (data, response) = try await URLSession.shared.data(for: request)
            
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                return .Falure(msg: ErrorCodes.UNKNOWN_ERROR)
            }
            
            let decodedData = try JSONDecoder().decode(T.self, from: data)
            return .Success(data: decodedData)
            
        } catch is DecodingError {
            return .Falure(msg: ErrorCodes.UNKNOWN_ERROR)
        } catch {
            return .Falure(msg: ErrorCodes.NO_INTERNET)
        }
    }
    
    /// Generic PUT function to send an Encodable body and decode JSON response
    func put<T: Decodable, B: Encodable>(urlString: String, body: B, headers: [String: String] = [:]) async -> ApiState<T> {
        guard let url = URL(string: urlString) else {
            return .Falure(msg: ErrorCodes.URL_INVALID)
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        headers.forEach { request.setValue($1, forHTTPHeaderField: $0) }
        
        do {
            request.httpBody = try JSONEncoder().encode(body)
            
            let (data, response) = try await URLSession.shared.data(for: request)
            
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                return .Falure(msg: ErrorCodes.UNKNOWN_ERROR)
            }
            
            let decodedData = try JSONDecoder().decode(T.self, from: data)
            return .Success(data: decodedData)
            
        } catch is DecodingError {
            return .Falure(msg: ErrorCodes.UNKNOWN_ERROR)
        } catch {
            return .Falure(msg: ErrorCodes.NO_INTERNET)
        }
    }
}
