//
//  ApiState.swift
//  WeatherApp
//
//  Created by Shubhamjit on 24/08/26.
//

enum ApiState <T> {
    case Idle
    case Laoding
    case Success(data : T)
    case Falure(msg : ErrorCodes)
}


enum ErrorCodes : Error {
    case NO_INTERNET, CONNECTION_TIMEOUT, NO_DATA_FOUND, UNKNOWN_ERROR, URL_INVALID
}


