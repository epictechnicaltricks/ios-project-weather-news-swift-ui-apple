//
//  GlobalMappers.swift
//  WeatherApp
//
//  Created by Shubhamjit on 26/08/26.
//

import SwiftUI





func getWeatherCondition(code: Int) -> String {
    switch code {
    case 0: return "Clear Sky"
    case 1, 2, 3: return "Partly Cloudy"
    case 45, 48: return "Foggy"
    case 51, 53, 55, 61, 63, 65: return "Rainy"
    case 80, 81, 82: return "Showers"
    case 95, 96, 99: return "Thunderstorm"
    default: return "Unknown"
    }
}


func getWeatherIcon(code: Int) -> String {
    switch code {
    case 0: return "sun.max.fill"
    case 1, 2, 3: return "cloud.sun.fill"
    case 45, 48: return "cloud.fog.fill"
    case 51...65: return "cloud.rain.fill"
    case 80...82: return "cloud.heavyrain.fill"
    case 95...99: return "cloud.bolt.rain.fill"
    default: return "cloud.fill"
    }
}


func convertToIndianTime(inputDate : String) -> String {

    /// Converts a GMT/UTC string "2026-08-26T07:00" into Indian Standard Time (IST)
    /// 
            // 1. Parse the string treating it explicitly as GMT
            let inputFormatter = DateFormatter()
            inputFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm"
            inputFormatter.timeZone = TimeZone(abbreviation: "GMT")
            
            guard let date = inputFormatter.date(from: inputDate) else {
                return inputDate // Fallback if parsing fails
            }
            
            // 2. Format the date into Indian Standard Time (Asia/Kolkata)
            let outputFormatter = DateFormatter()
            outputFormatter.timeZone = TimeZone(identifier: "Asia/Kolkata")
            outputFormatter.dateFormat = "hh:mm a, dd MMM yyyy"
            
            return outputFormatter.string(from: date)
     
}
