//
//  Extensions.swift
//  WeatherApp
//
//  Created by Shubhamjit on 26/08/26.
//


import Foundation

extension String {
    
   
}
