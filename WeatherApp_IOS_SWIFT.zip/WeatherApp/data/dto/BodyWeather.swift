//
//  BodyWeather.swift
//  WeatherApp
//
//  Created by Shubhamjit on 24/08/26.
//



struct BodyWeather : Codable {
    var cityName : String
    var lat : Double = -1
    var lon : Double = -1
}
