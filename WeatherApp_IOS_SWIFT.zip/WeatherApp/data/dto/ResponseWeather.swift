//
//  ResponseWeather.swift
//  WeatherApp
//
//  Created by Shubhamjit on 24/08/26.
//


struct ResponseWeather: Codable {
    let latitude: Double
    let longitude: Double
    let generationtimeMs: Double
    let utcOffsetSeconds: Int
    let timezone: String
    let timezoneAbbreviation: String
    let elevation: Double
    let currentUnits: CurrentUnitsDTO
    let current: CurrentDTO
    
    enum CodingKeys: String, CodingKey {
        case latitude
        case longitude
        case generationtimeMs = "generationtime_ms"
        case utcOffsetSeconds = "utc_offset_seconds"
        case timezone
        case timezoneAbbreviation = "timezone_abbreviation"
        case elevation
        case currentUnits = "current_units"
        case current
    }
}


struct CurrentUnitsDTO: Codable {
    let time: String
    let interval: String
    let temperature2m: String
    let weatherCode: String
    let windSpeed180m: String
    
    enum CodingKeys: String, CodingKey {
        case time
        case interval
        case temperature2m = "temperature_2m"
        case weatherCode = "weather_code"
        case windSpeed180m = "wind_speed_180m"
    }
}


struct CurrentDTO: Codable {
    let time: String
    let interval: Int
    let temperature2m: Double
    let weatherCode: Int
    let windSpeed180m: Double
    
    enum CodingKeys: String, CodingKey {
        case time
        case interval
        case temperature2m = "temperature_2m"
        case weatherCode = "weather_code"
        case windSpeed180m = "wind_speed_180m"
    }
}
