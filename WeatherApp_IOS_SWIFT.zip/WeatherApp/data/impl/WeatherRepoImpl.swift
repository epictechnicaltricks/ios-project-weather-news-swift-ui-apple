//
//  WeatherRepoImpl.swift
//  WeatherApp
//
//  Created by Shubhamjit on 25/08/26.
//

import SwiftUI

class WeatherRepoImpl: WeatherRepo {
    
    private let client = ApiClient.shared
    
    private func buildWeatherUrl(lat: Double, lon: Double) -> String {
        return "https://api.open-meteo.com/v1/forecast?latitude=\(lat)&longitude=\(lon)&current=temperature_2m,weather_code,wind_speed_180m&current_units=temperature_2m,wind_speed_180m"
    }
    
    
    
    func getWeather(body: BodyWeather) async throws -> ApiState<ResponseWeather> {
        let urlString = buildWeatherUrl(lat: body.lat, lon: body.lon)
        return await client.get(urlString: urlString)
    }
}
