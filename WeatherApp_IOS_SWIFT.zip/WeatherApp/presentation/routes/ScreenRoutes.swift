//
//  routes.swift
//  WeatherApp
//
//  Created by Shubhamjit on 24/08/26.
//

enum ScreenRoutes: Hashable {
    case privacy
}
