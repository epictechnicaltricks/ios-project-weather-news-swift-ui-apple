//
//  PrivacyScreen.swift
//  WeatherApp
//
//  Created by Shubhamjit on 24/08/26.
//

import SwiftUI

struct PrivacyScreen : View {
    
    var onClose : (() -> Void)? = nil
    
    
    var body : some View {
        VStack (alignment: .leading, spacing: 10){
            
            HStack {
                Text("Privacy Policy")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundColor(.white)

                Spacer()
                
                Button(
                    action : {
                        onClose?()
                    }
                ){
                    Image(systemName: "xmark")
                        .font(
                            .system(size: 16, weight: .bold)
                        )
                        .foregroundColor(Color.white)
                        .padding()
                        .background(Color.white.opacity(0.24))
                        .clipShape(Circle())
                }
                        
             }.padding()
                
                
               
            
            
            ScrollView {
                Text("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.")
                    .font(.system(size: 15, weight: .light))
                    .foregroundColor(.white.opacity(0.7))
                    .multilineTextAlignment(.leading)
                    .padding()
            }
            
            
            
            Spacer()
            
            
        }.frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.green)
            .navigationBarBackButtonHidden(true)
            .gesture(
                        DragGesture()
                            .onEnded { value in
                                // swipe from left edge, moved right at least 80pt, mostly horizontal
                                if value.startLocation.x < 30,
                                   value.translation.width > 80,
                                   abs(value.translation.height) < 60 {
                                    onClose?()
                                }
                            }
                    )
    }
    
}

#Preview {
    ZStack {
        Color.blue.ignoresSafeArea()
      PrivacyScreen()
    }

}
