import SwiftUI

struct MainScreen: View {
    @State private var path = NavigationPath()
    @State private var viewModel = MainScreenViewModel()
    
    let latitude = 20.2961
    let longitude = 85.8245
    
    
    var body: some View {
        NavigationStack(path: $path) {
            ZStack {
                Color.blue.ignoresSafeArea()
                
                VStack {
                    TopSection_UI(
                        onClose: {
                            exit(0)
                        },
                        onRefresh: {
                            print("refresh on click")
                            Task {
                                await viewModel.getWeather(
                                    body: BodyWeather(
                                        cityName: "Bhubaneswar",
                                        lat: latitude,
                                        lon: longitude
                                    )
                                )
                            }
                        },
                        onPrivacy: {
                            path.append(ScreenRoutes.privacy)
                            
                        }
                    )
                    
                    Spacer()
                    switch viewModel.weatherData {
                    case .Idle:
                        Text("Tap refresh to fetch weather")
                            .foregroundColor(.white)
                    case .Laoding:
                        ProgressView()
                            .frame(width: 100, height: 100)
                    case .Success(let data):
                        WeatherCard_UI(weatherData: data)
                    case .Falure(let msg):
                        Text("Error Loading : \(msg.localizedDescription)").foregroundColor(.red).background(.white)
                    }
                    
                    Spacer()
                }
                .padding()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            .navigationDestination(for: ScreenRoutes.self) { destination in
                switch destination {
                case .privacy:
                    PrivacyScreen(onClose: {
                        path.removeLast()
                    })
                    
                }
            }
        }.task {
            await viewModel.getWeather(
                body: BodyWeather(
                    cityName: "Bhubaneswar",
                    lat: latitude,
                    lon: longitude
                )
            )
        }
        
        
        
        /**
         .sheet(isPresented: $showPrivacyScreen) {
         PrivacyScreen(
         onClose: {
         showPrivacyScreen = false
         }
         )
         }
         **/
        
    }
}

#Preview {
    MainScreen()
}
