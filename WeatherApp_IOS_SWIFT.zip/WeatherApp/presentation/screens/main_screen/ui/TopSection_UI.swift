//
//  TopSection_UI.swift
//  WeatherApp
//
//  Created by Shubhamjit on 24/08/26.
//

import SwiftUI


struct TopSection_UI : View {
    var onClose : (() -> Void)? = nil
    var onRefresh : (() -> Void)? = nil
    var onPrivacy : (() -> Void)? = nil
    
    var body : some View {
        HStack {
            Button(
                action: {
                    onClose?()
                    // close app
                    
                }){
                    Image(systemName: "xmark")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.white.opacity(0.25))
                        .clipShape(Circle())
                }
            
            Spacer()
            
            Button(action: {
                onRefresh?()
                // refresh action
                 
            }){
                Image(systemName: "arrow.clockwise")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(.white)
                    .padding(12)
                    .background(Color.white.opacity(0.25))
                    .clipShape(Circle())
            }
            
            Spacer().frame(width: 15)
            
            Button(action: {
                onPrivacy?()
                // refresh action
                 
            }){
                Image(systemName: "hand.raised")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(.white)
                    .padding(12)
                    .background(Color.white.opacity(0.25))
                    .clipShape(Circle())
            }
            
        }
    }
}

#Preview {
    ZStack {
        Color.blue.ignoresSafeArea()
        TopSection_UI()
    }
}
