import SwiftUI

struct WeatherCard_UI: View {
    
    let weatherData : ResponseWeather
    
    var body: some View {
        VStack(spacing: 12) {
            // City Name
            Text("Bhubaneswar")
                .font(.system(size: 34, weight: .bold))
                .foregroundColor(.white)

            // Update Time
            Text("Last Update : \(convertToIndianTime(inputDate: weatherData.current.time))")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.white.opacity(0.8))

            // Weather Emoji
            Image(systemName: getWeatherIcon(code: weatherData.current.weatherCode))
                .font(.system(size: 75, weight: .bold))
                .frame(width: 100, height: 100)
                .foregroundColor(.white)
                .padding(.vertical, 4)

            // Temperature
            Text("\(String(format: "%.1f", weatherData.current.temperature2m))\(weatherData.currentUnits.temperature2m)")
                .font(.system(size: 56, weight: .medium))
                .foregroundColor(.white)

            // Condition Description
            Text(getWeatherCondition(code: weatherData.current.weatherCode))
                .font(.system(size: 18, weight: .medium))
                .foregroundColor(.white.opacity(0.9))

            // Horizontal Divider Line
            Divider()
                .frame(width: 220, height: 1)
                .background(Color.white.opacity(0.7))
                .padding(.vertical, 8)

            // Wind Speed
            Text("💨 Wind Speed : \(String(format: "%.1f", weatherData.current.windSpeed180m))\(weatherData.currentUnits.windSpeed180m)")
                .font(.system(size: 16, weight: .regular))
                .foregroundColor(.white)
        }
        .padding(.vertical, 28)
        .frame(maxWidth: .infinity)
        .background(Color.white.opacity(0.20))
        .cornerRadius(32)
        .padding(.horizontal, 20)
    }
}



