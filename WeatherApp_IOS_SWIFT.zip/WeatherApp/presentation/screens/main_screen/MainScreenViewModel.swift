//
//  MainScreenViewModel.swift
//  WeatherApp
//
//  Created by Shubhamjit on 25/08/26.
//

import SwiftUI

@Observable
final class MainScreenViewModel {
    
    private let repo: WeatherRepo
    
    private(set) var weatherData: ApiState<ResponseWeather> = .Idle
    
    init(repo: WeatherRepo = WeatherRepoImpl()) {
            self.repo = repo
        }
    
    func getWeather(body: BodyWeather) async {
            self.weatherData = .Laoding
            do {
                self.weatherData = try await repo.getWeather(body: body)
            } catch {
                self.weatherData = .Falure(msg: ErrorCodes.UNKNOWN_ERROR)
            }
        }
    
   
}



