//
//  WeatherRepro.swift
//  WeatherApp
//
//  Created by Shubhamjit on 24/08/26.
//

protocol WeatherRepo {
    func getWeather(body : BodyWeather) async throws -> ApiState<ResponseWeather>
}
