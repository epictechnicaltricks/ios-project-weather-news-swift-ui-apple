//
//  WeatherAppApp.swift
//  WeatherApp
//
//  Created by Shubhamjit on 24/08/26.
//

import SwiftUI

@main
struct WeatherApp: App {
    var body: some Scene {
        WindowGroup {
            MainScreen()
        }
    }
}
