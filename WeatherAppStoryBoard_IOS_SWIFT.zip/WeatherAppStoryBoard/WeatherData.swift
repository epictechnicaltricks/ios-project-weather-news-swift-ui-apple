//
//  WeatherData.swift
//  WeatherAppStoryBoard
//
//  Created by Shubhamjit on 09/09/26.
//

import Foundation


struct WeatherData {
    let cityName : String
    let temperature : String
    let condition : String
}


class WeatherDataManager {
    
    static var weatherList = [WeatherData]()
    
    static var shared = WeatherDataManager()
    
    private init() {}
    
    func addWeatherData(data : WeatherData) {
        
//        let url = URL(string: //"https://api.open-meteo//.com/v1/forecast?latitude=\(lat)&longitude=\(lon)&current=temperature_2m,weather_code,wind_speed_180m&current_units=temperature_2m,wind_speed_180m")!
//
//        URLSession.shared.dataTask(with: url) { (data, response, error) in
//            guard data != nil, error == nil else {
//                DispatchQueue.main.async {
//                    completion(.failure(error!))
//                }
//                return
//                
//            }
            
        
            
//            DispatchQueue.main.async {
//                completion(.success(
//                    dataw
//                ))
//                
                WeatherDataManager.weatherList.append(data)
            }
          
                       
                       
    
    func removeWeatherData(at index: Int) {
        guard index >= 0 && index < WeatherDataManager.weatherList.count else { return }
        WeatherDataManager.weatherList.remove(at: index)
    }
    

                       
    }
    
    
    
