//
//  WeatherReportTableViewController.swift
//  WeatherAppStoryBoard
//
//  Created by Shubhamjit on 09/09/26.
//

import UIKit

class WeatherReportTableViewController: UITableViewController, WeatherRepo {
    
    
  

    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        WeatherDataManager.weatherList = [
            WeatherData(cityName: "BBSR", temperature: "22", condition: "BAD"),
            WeatherData(cityName: "BBSR2", temperature: "0", condition: "GOOD"),
            WeatherData(cityName: "CTC 4", temperature: "22", condition: "BAD"),
            WeatherData(cityName: "BBSR", temperature: "22", condition: "BAD"),
            WeatherData(cityName: "BBSR2", temperature: "0", condition: "GOOD"),
            WeatherData(cityName: "CTC 4", temperature: "22", condition: "BAD")
        ]

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return WeatherDataManager.weatherList.count
    }

  
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celll", for: indexPath)

        cell.textLabel?.text = WeatherDataManager.weatherList[indexPath.row].cityName
        cell.detailTextLabel?.text = "\(WeatherDataManager.weatherList[indexPath.row].temperature)C | \(WeatherDataManager.weatherList[indexPath.row].condition)"
        
        cell.backgroundColor = Int(WeatherDataManager.weatherList[indexPath.row].temperature) ?? 0 > 10 ? .green: .blue
        

        return cell
    }
 

    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        
        
        return true
    }
    
    func addData(weatherData: WeatherData) {
        WeatherDataManager.weatherList.append(weatherData)
        tableView.reloadData()
    }
    
    func cancel(){
    }
    
    

    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            WeatherDataManager.shared.removeWeatherData(at: indexPath.row)
            print("aabra kaabda  \(indexPath.row)")
            tableView.reloadData()
        }
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */


    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let addVC = segue.destination as? AddViewController
        addVC?.weatherRepo = self
    }


}
