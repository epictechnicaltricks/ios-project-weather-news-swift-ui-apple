//
//  AddViewController.swift
//  WeatherAppStoryBoard
//
//  Created by Shubhamjit on 09/09/26.
//

import UIKit

protocol WeatherRepo {
    func addData(weatherData: WeatherData)
    func cancel()
}

class AddViewController: UIViewController {
    
    
    @IBOutlet weak var cityName: UITextField!
    
    
    @IBOutlet weak var tempData: UITextField!
    
    
    @IBOutlet weak var conditionInfo: UITextField!
    
    var weatherRepo: WeatherRepo? = nil
    
    
    @IBAction func Bookmark(_ sender: Any) {
       let alert =  UIAlertController(
            title: "BOOKMARKED ✅", message: "ITS DONE BRO", preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "OK", style:.default))
        
                        self.present(alert, animated: true)
        
      
    }
    
    
    @IBAction func Save(_ sender: Any) {
        if cityName.text == "" || tempData.text == "" || conditionInfo.text == "" {
            let alert = UIAlertController(title: "Error", message: "Please enter all the fields", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            self.present(alert, animated: true)
        } else {
            weatherRepo?.addData(weatherData: WeatherData(
                cityName: cityName.text!, temperature: tempData.text!, condition: conditionInfo.text!
            ))
            //self.dismiss(animated: true)
            self.navigationController?.popViewController(animated: true)
        }
    }
    

     
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
