//
//  App.swift
//  AppleTV+ Clone
//
//  Created by Shubhamjit on 21/09/26.
//


import SwiftUI

@main
struct ShubhamjitAppleClone : App {
    var body : some Scene {
        WindowGroup {
            DashabordScreen()
        }
    }
}
