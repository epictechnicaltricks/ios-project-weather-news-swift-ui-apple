//
//  DetailsScreen.swift
//  AppleTV+ Clone
//
//  Created by Shubhamjit on 21/09/26.
//

import SwiftUI

struct DetailsScreen : View {
    var body : some View {
        VStack {
            Spacer()
            Text("This is the Details Screen")
                .font(.system(size: 20, weight: .bold))
            Spacer()
        }
    }
}
