//
//  SidebarScreen.swift
//  AppleTV+ Clone
//
//  Created by Shubhamjit on 21/09/26.
//

import SwiftUI

struct NavItemData: Identifiable {
    let id = UUID()
    let iconsName: String
    let navName: String
}

struct SidebarScreen: View {

    private let navItems: [NavItemData] = [
        NavItemData(iconsName: "magnifyingglass", navName: "Search"),
        NavItemData(iconsName: "house", navName: "Home"),
        NavItemData(iconsName: "video", navName: "Live TV"),
        NavItemData(iconsName: "doc.text", navName: "Privacy"),
    ]

    @State private var selectedItem: NavItemData?
    @FocusState private var focusedItem: NavItemData.ID?

    var body: some View {
        VStack {
            Spacer().frame(height: 20)
                List(navItems) { item in
                   
                    HStack {
                        
                        Image(systemName: item.iconsName)
                            .frame(width: 30, height: 30)
                            .scaledToFill()
                            .padding(.vertical, 20)
                            .padding(.horizontal, 20)
                            .foregroundColor(focusedItem == item.id ? .black : .white)

                        Text(item.navName)
                            .padding(.leading, -40)
                            .lineLimit(1)
                            .padding(.vertical, 20)
                            .foregroundColor(focusedItem == item.id ? .black : .white)

                        Spacer().frame(maxHeight: .infinity)
                        
                    }.background(
                            RoundedRectangle(cornerRadius: 20)
                                .fill(focusedItem == item.id ? .white.opacity(0.9) : .clear)
                        )
                    .scaleEffect(focusedItem == item.id ? 1.04 : 1.0)
                    .focusable(true)
                    .onTapGesture {
                        selectedItem = item
                    }
                    .buttonStyle(.plain)
                    .focused($focusedItem, equals: item.id)
                    .animation(.easeOut(duration: 0.2), value: focusedItem)
                }
                .onAppear { focusedItem = navItems.first?.id }
            }
            .frame(width: 400)
            .glassEffect(.regular.tint(.black.opacity(0.3)), in: .rect(cornerRadius: 30))
            .padding(.all, 5)
    }
}

#Preview {
    ZStack {
        Color.white.ignoresSafeArea()
        SidebarScreen()
    }
}
