//
//  ScreenRoutes.swift
//  AppleTV+ Clone
//
//  Created by Shubhamjit on 21/09/26.
//


enum ScreenRoutes : Hashable {
    case Home
    case Details (path : String)
}
