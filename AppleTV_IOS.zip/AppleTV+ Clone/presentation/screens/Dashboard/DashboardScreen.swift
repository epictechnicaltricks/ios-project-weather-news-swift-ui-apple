//
//  Dashboard.swift
//  AppleTV+ Clone
//
//  Created by Shubhamjit on 21/09/26.
//


import SwiftUI

struct DashabordScreen : View {
    
    @State private var nativationPath = NavigationPath()
    
    var body : some View {
       
    
        NavigationStack(path: $nativationPath) {
           HomeScreen().background(.green)
        }.navigationDestination(for: ScreenRoutes.self) { screen in
            switch screen {
            case .Home : HomeScreen()
            case .Details(_) : DetailsScreen()
            }
        }
        
       
    }
}
