//
//  slider_home.swift
//  AppleTV+ Clone
//
//  Created by Shubhamjit on 23/09/26.
//

import SwiftUI


struct SliderHome : View {
    
    @State private var selectedIndex = 0
    
    var body : some View {
       
        TabView(selection: $selectedIndex) {
            
                    ForEach(
                        Array(dummySliderData.enumerated()),
                        id: \.element.id
                    ) { index, data in

                        SliderItemView(
                            bannerData: data,
                            ctaOnClick: { data in
                                print(data.title)
                            },
                            addFavOnClick: { data in
                                print(data.title)
                            }
                        )
                        .tag(index)
                    }
                }
                .tabViewStyle(
                    .page(indexDisplayMode: .always)
                )
        
       
    }
    
}


struct SliderItemView : View {
    
    let bannerData : SliderData
    
    let ctaOnClick : (SliderData) -> Void
    let addFavOnClick : (SliderData) -> Void
    
    @FocusState var state : SliderData.ID?
    
    var body: some View {
        
        ZStack(alignment: .bottomLeading) {
            
            Color.black.ignoresSafeArea()
            
            
            AsyncImage(
                url: URL(string: bannerData.bannerImage)){image in
                    image.resizable().scaledToFill()
                } placeholder: {
                    Color.gray
                }
                .clipped()
            
            
            LinearGradient(
                colors: [Color.black.opacity(1), .clear],
                startPoint: .bottomLeading,
                endPoint: .top
            )
            
            
            
            VStack(alignment: .leading,spacing: 16) {
                
                Text(bannerData.title)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                
               
                
                Text(bannerData.movieInfo)
                    .font(.subheadline)
                    .fontWeight(.regular)
                    .foregroundColor(.white.opacity(0.9))
                
                Text(bannerData.movieDescription)
                    .foregroundColor(.gray)
                    .font(.caption).lineLimit(2)
                    
                HStack {
                    Button {
                        ctaOnClick(bannerData)
                    } label: {
                        Text("Sign Up to Watch")
                            .font(.default)
                            .foregroundStyle(.black)
                            .padding(.horizontal, 30)
                            .padding(.vertical, 16)
                            .background(.white)
                            .clipShape(Capsule())
                    }
                        .buttonStyle(.plain)
                        .foregroundColor(.white)
                    
                    Button {
                        print("added")
                    } label: {
                        
                        Image(
                            systemName: "plus"
                        ).frame(width: 20, height: 30)
                            .foregroundColor(.white)
                            
                    }.padding(.leading, -40)

                    
                }.padding(.top, 30)
                
                
                
            }.padding(.leading, 100).padding(.bottom, 45)
           

        }
        .focusable()
       
        
    }
}

struct SliderData : Identifiable{
    let id = UUID()
    var bannerImage : String = ""

    var title : String = "Shubhamjit ke Stroy"
    var movieInfo : String = "tv   TV Show · Comedy   Ⓐ"
    var movieDescription: String = "Two of Hollywood’s biggest stars discover their friendship might just run in the family."
    var movieId: String = "iD"
}

#Preview {
    ZStack {
        Color.black.ignoresSafeArea()
        SliderHome()
    }
}


