//
//  HomeScreen.swift
//  AppleTV+ Clone
//
//  Created by Shubhamjit on 21/09/26.
//

import SwiftUI

struct HomeScreen: View {
    
    var body: some View {
        
        ZStack(alignment: .leading) {
            
            Image("bg")
                .resizable()
                .scaledToFill()
                .frame(maxWidth: .infinity, maxHeight: .infinity)

            VStack(alignment: .leading) {
                
                SliderHome()
                
            }
            .frame(
                maxWidth: .infinity,
                maxHeight: .infinity
            )
            

            SidebarScreen()
                
        }
        .frame(
            maxWidth: .infinity,
            maxHeight: .infinity
        )
        .ignoresSafeArea()
    

    }
    
    
}

#Preview {
    ZStack {
        Color.black.ignoresSafeArea()
        HomeScreen()
    }
}
