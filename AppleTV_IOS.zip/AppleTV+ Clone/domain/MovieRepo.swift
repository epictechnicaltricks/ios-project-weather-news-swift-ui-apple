//
//  MovieRepo.swift
//  AppleTV+ Clone
//
//  Created by Shubhamjit on 23/09/26.
//

protocol MovieRepo {
    func getTrendingMovies()
}
