//
//  DummyDumpArea.swift
//  AppleTV+ Clone
//
//  Created by Shubhamjit on 27/09/26.
//

let dummySliderData: [SliderData] = [
    SliderData(
        bannerImage: "https://image.tmdb.org/t/p/original/dUVbWINfRMGojGZRcO6GF1Z2nV8.jpg",
        title: "The Dark Knight",
        movieInfo: "tv   Movie · Action   Ⓐ",
        movieDescription: "Batman faces a criminal mastermind who plunges Gotham City into chaos.",
        movieId: "movie_001"
    ),

    SliderData(
        bannerImage: "https://image.tmdb.org/t/p/original/dqK9Hag1054tghRQSqLSfrkvQnA.jpg",
        title: "The Dark Knight",
        movieInfo: "tv   Movie · Drama   Ⓐ",
        movieDescription: "A legendary hero faces his greatest challenge in Gotham City.",
        movieId: "movie_002"
    ),

    SliderData(
        bannerImage: "https://image.tmdb.org/t/p/original/yzqaKAhglTrkeOfuIXYYArf0WnA.jpg",
        title: "Finding Nemo",
        movieInfo: "tv   Movie · Animation   Ⓐ",
        movieDescription: "A father crosses the ocean to find his missing son and bring him home.",
        movieId: "movie_003"
    ),

    SliderData(
        bannerImage: "https://image.tmdb.org/t/p/original/5YZbUmjbMa3ClvSW1Wj3D6XGolb.jpg",
        title: "Guardians of the Galaxy Vol. 3",
        movieInfo: "tv   Movie · Adventure   Ⓐ",
        movieDescription: "The Guardians come together for one final mission to protect one of their own.",
        movieId: "movie_004"
    ),

    SliderData(
        bannerImage: "https://image.tmdb.org/t/p/original/bsNm9z2TJfe0WO3RedPGWQ8mG1X.jpg",
        title: "Breaking Bad",
        movieInfo: "tv   TV Show · Drama   Ⓐ",
        movieDescription: "A chemistry teacher enters a dangerous new world after a life-changing diagnosis.",
        movieId: "movie_005"
    )
]
