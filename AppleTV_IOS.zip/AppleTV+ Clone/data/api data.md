Here's the core TMDB endpoints you need, using your key:

**Base URL:** `https://api.themoviedb.org/3`

**1. Trending movies (day/week)**
```
GET /trending/movie/day?api_key=4f15894c1537741f87be275b26aaf51f
GET /trending/movie/week?api_key=4f15894c1537741f87be275b26aaf51f
```

**2. Top rated movies**
```
GET /movie/top_rated?api_key=4f15894c1537741f87be275b26aaf51f&page=1
```

**3. Now playing / recent releases**
```
GET /movie/now_playing?api_key=4f15894c1537741f87be275b26aaf51f&page=1
```

**4. Genre-filtered (sci-fi, comedy, etc.) — use Discover**

First get genre IDs:
```
GET /genre/movie/list?api_key=4f15894c1537741f87be275b26aaf51f
```
Common ones: Sci-Fi = 878, Comedy = 35, Action = 28, Horror = 27, Drama = 18

Then filter:
```
GET /discover/movie?api_key=4f15894c1537741f87be275b26aaf51f&with_genres=878&sort_by=popularity.desc
```

Multiple genres (AND): `with_genres=878,35`
Multiple genres (OR): `with_genres=878|35`

**5. Popular movies (general trending-ish list)**
```
GET /movie/popular?api_key=4f15894c1537741f87be275b26aaf51f&page=1
```

**Quick tip:** append your key as query param or better, use a header:
```
Authorization: Bearer <v4_read_access_token>
```
(the `api_key` param works with your v3 key like above — simpler for testing).

Want a minimal Kotlin Retrofit interface for these since you're on Android?
