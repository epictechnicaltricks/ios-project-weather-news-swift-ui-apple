//
//  ApiState.swift
//  AppleTV+ Clone
//
//  Created by Shubhamjit on 23/09/26.
//


enum ApiState<R> {
    case Idle
    case Loading
    case Success(data : R)
    case Failure(errorType : NetworkError)
}

enum NetworkError : Error {
    case ConnectionTimeOut
    case NoInternet
    case InValidUrl
    case UnknownError
}


