//
//  ApiType.swift
//  AppleTV+ Clone
//
//  Created by Shubhamjit on 23/09/26.
//



enum ApiType {
    case GET
    case POST
    case PUT
    case DELETE
}
