//
//  ApiClient.swift
//  AppleTV+ Clone
//
//  Created by Shubhamjit on 23/09/26.
//

import SwiftUI

class ApiClient {
    
    static private(set) var shared = ApiClient()
    
    private init() {}
    
    private let baseUrl = "https://api.themoviedb.org/3"
    
    func call<B : Encodable, R : Decodable>(
        apiBody : B? = nil,
        apiType : ApiType) async ->  ApiState<R> {
        
        //check the url
        guard let finalBaseUrl = URL(string: baseUrl) else {
            return .Failure(errorType: .InValidUrl)
        }
        
        
        
        //decode body
        var urlRequest = URLRequest(url: finalBaseUrl)
        
        if apiBody != nil {
            guard let body = try? JSONEncoder().encode(apiBody) else {
                          return .Failure(errorType: .InValidUrl) // or a dedicated .EncodingError
                      }
                      urlRequest.httpBody = body
        }
       
            urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
            
            
        urlRequest.httpMethod  =    switch apiType {
        case .GET :  "GET"
        case .POST : "POST"
        case .DELETE : "DELETE"
        case .PUT : "PUT"
        }
       
        do {
            let (data, response) = try await URLSession.shared.data(for: urlRequest)
            
            guard let httpResponse = response as? HTTPURLResponse ,(200...299).contains(httpResponse.statusCode) else {
                
                return .Failure(errorType: .UnknownError)
               
            }
            
            let finalData =  JSONDecoder()
            finalData.dateDecodingStrategy = .iso8601
            
            
            return .Success(data: try finalData.decode(R.self, from:data))
            
            
            
        } catch {
           return .Failure(errorType: .NoInternet)
        }
    }
    
}
