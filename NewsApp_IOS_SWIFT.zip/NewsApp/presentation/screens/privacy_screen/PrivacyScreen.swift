//
//  PrivacyScreen.swift
//  NewsApp
//
//  Created by Shubhamjit on 28/08/26.
//

import SwiftUI

struct PrivacyScreen : View {
    
    let onClose : () -> Void
    
    var body : some View {
        
        
        VStack {
            
            HStack {
                Text("Privacy Policy")
                    .font(.system(size: 30, weight: .bold))
                    .foregroundColor(.black)
                Spacer()
                
                Button ( action : {
                    onClose()
                }) {
                    Image(systemName: "xmark")
                        .font(.system(size: 20, weight: .bold))
                        .padding(10)
                        .foregroundColor(.white)
                        .background(Color.black.opacity(0.8))
                        .clipShape(Circle())
                    
                    
                }
            }.padding()
            
            ScrollView {
                Text("This was lored txt need to fill be some one i not using ai here using only my own finger and keybaordnot ai are hard on this proejct so this eas dummy priacy policy so code copied from ai here This was lored txt need to fill be some one i not using ai here using only my own finger and keybaordnot ai are hard on this proejct so this eas dummy priacy policy so code copied from ai here This was lored txt need to fill be some one i not using ai here using only my own finger and keybaordnot ai are hard on this proejct so this eas dummy priacy policy so code copied from ai here This was lored txt need to fill be some one i not using ai here using only my own finger and keybaordnot ai are hard on this proejct so this eas dummy priacy policy so code copied from ai here This was lored txt need to fill be some one i not using ai here using only my own finger and keybaordnot ai are hard on this proejct so this eas dummy priacy policy so code copied from ai here This was lored txt need to fill be some one i not using ai here using only my own finger and keybaordnot ai are hard on this proejct so this eas dummy priacy policy so code copied from ai here This was lored txt need to fill be some one i not using ai here using only my own finger and keybaordnot ai are hard on this proejct so this eas dummy priacy policy so code copied from ai here This was lored txt need to fill be some one i not using ai here using only my own finger and keybaordnot ai are hard on this proejct so this eas dummy priacy policy so code copied from ai here")
                    .foregroundStyle(Color.gray)
            }
            
        }.frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarBackButtonHidden(true)
    }
    
}

#Preview {
    ZStack {
        PrivacyScreen(onClose: {})
    }
    
}
