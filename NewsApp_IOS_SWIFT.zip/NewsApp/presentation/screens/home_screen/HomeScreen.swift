//
//  HomeScreen.swift
//  NewsApp
//
//  Created by Shubhamjit on 28/08/26.
//

import SwiftUI

struct HomeScreen : View {
    
    let onPrivacyClick: () -> Void
    
    @State private var vm  = HomeScreenViewModel()
    
    let onDetailsClick : (Article) -> Void
    
    var body : some View {
        VStack {
            Toolbar_UI(onPrivacyClick: self.onPrivacyClick)
            
            SearchBar_UI(vm: vm)
            
            
            switch vm.getNewsTrendingState {
            case .Failed(let error) :
                switch error {
                case .InvalidURL : Text("InvalidURL")
                
                case .NoInternet : Text("NoInternet")
                    
                case .UnknownError :Text("UnknownError")
                }
               
            case .Success(let newsData) :
                NewsList_Ui(
                    articles: newsData.articles, onDetailsClick: { articleData in
                        onDetailsClick(articleData)
                    }
                )
                    
                
            case .Laoding :
                ProgressView().frame(maxWidth: .infinity)
            case .Idle:
                Text("NO NEWS FOUND!")
            }
            Spacer()
        }.task() {
            //*** you forgot await
            
           await vm.getTrendingNews(body: BodyNews(countryCode: "US"))
            
            
        }
    }
    
}
























struct NewsData : Codable, Identifiable {
    var id = UUID()
    
    var title: String = "iPhone 18 Pro, Pro Max price hike expected in India; foldable Ultra could be Apple’s most expensive phone"
    
    var desc: String = """
    Apple is preparing for its next major hardware event on 9 September, with the new iPhone lineup expected to headline. While the company has not confirmed the products, strong indications point to the launch of iPhone 18 Pro and iPhone 18 Pro Max. The long-rumoured foldable iPhone may also make its big debut.

    Leaks suggest Indian buyers could face higher prices this year, tied to memory and storage costs. Apple has not disclosed official prices, so reported prices remain indicative rather than final retail tags.

iPhone 18 Pro price (expected)
The Apple iPhone 18 Pro is expected to start at ₹139,900 in India, approximately ₹5,000 more than the iPhone 17 Pro, which retails at ₹134,900.

The 256GB option is tipped to cost ₹144,900. The increase cements the Pro model's premium positioning, though Apple's track record shows Pro devices consistently outsell lower-cost counterparts, making the pricing easier to justify.
"""
    
    var bannerUrl: String = "https://www.deccanchronicle.com/h-upload/2026/08/09/2074208-17.webp"
    
    var dateTime : String = "27 Aug 2026, 12:21 PM IST"
    
  
}
