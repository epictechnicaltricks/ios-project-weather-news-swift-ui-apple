//
//  NewsList_UI.swift
//  NewsApp
//
//  Created by Shubhamjit on 28/08/26.
//

import SwiftUI

struct NewsList_Ui : View {
    
    
    var articles: [Article]
    
    let onDetailsClick : (Article) -> Void
    
    var body : some View {
        List(articles) { news in
            Button(action: {
                onDetailsClick(news)
            }){
                AsyncImage(url: URL(string:news.urlToImage ?? "")) { img in
                        img
                            .resizable()
                            .scaledToFit()
                    } placeholder: {
                        ProgressView().frame(maxWidth: .infinity)
                        // Shows a spinner while loading
                    }
                
                Text(news.title.trimmingCharacters(in: .whitespaces))
                            .font(.headline)
                            .foregroundColor(.black)
                            .lineLimit(2)
                       
            
                Text((news.description ?? "").trimmingCharacters(in: .whitespaces))
                            .font(.default)
                            .multilineTextAlignment(.leading)
                            .lineLimit(4)
                            .foregroundStyle(Color.gray)
                            .listRowSeparator(.hidden)
                Spacer().frame(height: 20)
                
                Text("Date: \(news.publishedAt)")
                    .font(.system(size: 14,weight: .light)).foregroundColor(.gray.opacity(0.9)).padding()

            }
                
        }
        .listStyle(.grouped)
        .background(.black)
    }
}
    
    func getNewslist()  -> [NewsData] {
        var news = [NewsData]()
        
        for i in 0..<10 {
            print(i)
            news.append(NewsData())
        }
        
        return news
    }
    
    
