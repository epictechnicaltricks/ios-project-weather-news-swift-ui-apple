//
//  SearchbAR_UI.swift
//  NewsApp
//
//  Created by Shubhamjit on 06/09/26.
//

import SwiftUI

struct SearchBar_UI : View {
    
    
    @Bindable var vm : HomeScreenViewModel
    
    var body : some View {
        
       
        Text("Search News")
            .font(.headline)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 5)
        
        TextField(text: $vm.searchValue, label: {
            Text("Search some news")
        }).onSubmit {
            Task {
                await vm.findNews(query: vm.searchValue)
                print("Search Value : \(vm.searchValue)")
            }
          
        }.frame(maxWidth: .infinity)
            .task(id: vm.searchValue)  {
                if vm.searchValue.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return }
                try? await Task.sleep(for: .milliseconds(2000))
                guard !Task.isCancelled else { return }
                await vm.findNews(query: vm.searchValue)
            }
            .foregroundColor(.white)
            .cornerRadius(20)
            .padding()
            
        
    }
}


