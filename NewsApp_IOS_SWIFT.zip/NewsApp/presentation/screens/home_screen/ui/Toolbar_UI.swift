//
//  Toolbar_UI.swift
//  NewsApp
//
//  Created by Shubhamjit on 28/08/26.
//

import SwiftUI


struct Toolbar_UI: View {
    let onPrivacyClick: () -> Void
    
    
    var body: some View {
        
        HStack {
            Text("NEWS APP")
                .font(.system(size: 25, weight: .bold))
                .foregroundColor(.white).padding()
                
            Spacer()
            
            Button(action : {
                onPrivacyClick()
            }) {
                Image(systemName: "hand.raised")
                    .font(.system(size: 20, weight: .bold))
                    .padding(10)
                    .foregroundColor(.white)
                    .background(.white.opacity(0.3))
                    .clipShape(Circle())
            }.padding()
        }
        .background(.black)
            
    }
    
}

#Preview {
    ZStack {
        Color.blue.ignoresSafeArea()
        Toolbar_UI(onPrivacyClick: {})
    }
    
}
