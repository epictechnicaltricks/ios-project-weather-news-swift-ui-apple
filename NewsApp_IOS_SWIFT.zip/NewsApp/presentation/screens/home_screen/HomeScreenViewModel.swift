//
//  HomeScreenViewModel.swift
//  NewsApp
//
//  Created by Shubhamjit on 31/08/26.
//

import SwiftUI

@Observable
class HomeScreenViewModel  {
    
    
   var searchValue = ""
    
    
    private var repo : NewsRepo
    
    init (repo : NewsRepo = NewsImpl()){
        self.repo = repo
    }
    
    // also stuck here ini of repo inst but i did wrongimpl insted of repo
    
    // not used private set
    
    private(set) var getNewsTrendingState : ApiState<NewsResponse> = .Idle
    
    func getTrendingNews(body: BodyNews) async {
        self.getNewsTrendingState = .Laoding
        do {
            self.getNewsTrendingState = try await repo.getTrendingNews()
        } catch let error as ApiError {
            self.getNewsTrendingState = .Failed(msg: error)
        }catch {
            self.getNewsTrendingState = .Failed(msg: .UnknownError)
        }
       
    }
    
    
    func findNews(query : String) async {
        self.getNewsTrendingState = .Laoding
        do {
            self.getNewsTrendingState = try await repo.findNews(query: query)
        } catch let error as ApiError {
            self.getNewsTrendingState = .Failed(msg: error)
        }catch {
            self.getNewsTrendingState = .Failed(msg: .UnknownError)
        }
    }
    
}
