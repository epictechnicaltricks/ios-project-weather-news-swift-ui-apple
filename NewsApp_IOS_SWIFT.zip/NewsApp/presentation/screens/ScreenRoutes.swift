//
//  routes.swift
//  NewsApp
//
//  Created by Shubhamjit on 28/08/26.
//
import SwiftUI

enum ScreenRoutes: Hashable {
    case home
    case details (Article)
    case privacy
}
