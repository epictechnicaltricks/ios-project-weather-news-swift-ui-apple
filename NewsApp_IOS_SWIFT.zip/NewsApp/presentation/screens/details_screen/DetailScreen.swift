//
//  DetailScreen.swift
//  NewsApp
//
//  Created by Shubhamjit on 28/08/26.
//

import SwiftUI
import WebKit

struct DetailScreen: View {
    
    let article: Article
    
    var body: some View {
        
        ScrollView {
            
            
            if let articleImage = article.urlToImage {
                AsyncImage(url: URL(string: articleImage)) { phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                            .frame(maxWidth: .infinity)
                            .frame(height: 200)
                    case .success(let image):
                        image.resizable()
                            .frame(maxWidth: .infinity)
                            .frame(height: 200)
                            .cornerRadius(30)
                    case .failure:
                        Image(systemName: "photo")
                            .frame(maxWidth: .infinity)
                            .frame(height: 200)
                            .foregroundColor(.gray)
                    @unknown default:
                        EmptyView()
                    }
                }.padding()
            }
            
            
            Text(article.title).font(.headline).padding()
            
            Text("Author : \(article.author ?? "Unknown")").font(.caption).padding()
            Spacer().frame(height: 10)
            Text("Date :\(article.publishedAt)").font(.default)
            Spacer().frame(height: 10)
            Text("Source : \(article.source.name)")
            Spacer().frame(height: 10)
            
            Divider().frame(maxWidth: .infinity).padding(.top, 20).foregroundColor(.black)
            
            
            if URL(string: article.urlToImage ?? "") != nil {
                WebView(url: URL(string: article.url)).frame(height: 1000)
            }
            
        }
  
    }
}
