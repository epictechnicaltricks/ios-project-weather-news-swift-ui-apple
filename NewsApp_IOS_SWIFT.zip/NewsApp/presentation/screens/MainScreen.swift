//
//  MainScreen.swift
//  NewsApp
//
//  Created by Shubhamjit on 28/08/26.
//

import SwiftUI

struct MainScreen : View {
    @State private var path = NavigationPath()
    
    var body : some View {
        NavigationStack(path : $path) {
            
            
            VStack {
                HomeScreen(
                    onPrivacyClick: {
                        path.append(ScreenRoutes.privacy)
                    },
                    onDetailsClick: { articleData in
                        path.append(ScreenRoutes.details(articleData))
                    }
                )
                
                
            }.navigationDestination(for: ScreenRoutes.self) { screen in
                    switch screen {
                    case .home :
                        
                        HomeScreen(
                            onPrivacyClick: {
                                path.append(ScreenRoutes.privacy)
                            },
                            onDetailsClick: { articleData in
                                path.append(ScreenRoutes.details(articleData))
                                
                            }
                        )
                        
                    case .privacy : PrivacyScreen(onClose: {
                        path.removeLast()
                         }
                    )
                    case .details(let articleData) : DetailScreen(article: articleData)
                        
                    }
                }
        }
    }
    
}


#Preview {
    ZStack {
        MainScreen()
    }
}
