//
//  NewsRepo.swift
//  NewsApp
//
//  Created by Shubhamjit on 31/08/26.
//


protocol NewsRepo {
    func getTrendingNews() async throws -> ApiState<NewsResponse>
    func findNews(query : String) async throws -> ApiState<NewsResponse>
}
