//
//  ApiClient.swift
//  NewsApp
//
//  Created by Shubhamjit on 31/08/26.
//


import SwiftUI


class ApiClient {
    
    let baseUrl = "https://newsapi.org/v2/top-headlines?country=us&apiKey=c714cf3d46e84f11b34bb53e21761345"
    

    private init() {}
    
    
    static let shared = ApiClient()
    
    func call<R : Decodable , B : Encodable>(
        apiType : ApiType,
        body : B? = nil,
        header: [String:String]? = nil
    ) async ->  ApiState<R> {
        
        
        guard let url = URL(string : baseUrl) else {
            return .Failed(msg: ApiError.InvalidURL)
        }
        
        
        var request = URLRequest(url: url)
        
        if let body {
            request.httpBody = try? JSONEncoder().encode(body)
        }
        
        
        switch apiType {
        case .GET: request.httpMethod = "GET"
        case .POST : request.httpMethod = "POST"
        case .DELETE : request.httpMethod = "DELETE"
        case .PUT : request.httpMethod = "PUT"
        }
        
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        if (header != nil) {
            header?.forEach {
                request.setValue($1, forHTTPHeaderField: $0)
            }
        }
        
        
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                return.Failed(msg: ApiError.UnknownError)
            }
        
            return .Success(data: try JSONDecoder().decode(R.self, from: data))
            
        }catch {
            return .Failed(msg: ApiError.UnknownError)
        }
        
        
    }
    
    
    
    
    
    
    func call<R : Decodable>(
        apiType : ApiType,
        header: [String:String]? = nil
    ) async ->  ApiState<R> {
        
        
        guard let url = URL(string : baseUrl) else {
            return .Failed(msg: ApiError.InvalidURL)
        }
        
        
        var request = URLRequest(url: url)
        
     
        
        
        switch apiType {
        case .GET: request.httpMethod = "GET"
        case .POST : request.httpMethod = "POST"
        case .DELETE : request.httpMethod = "DELETE"
        case .PUT : request.httpMethod = "PUT"
        }
        
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        if (header != nil) {
            header?.forEach {
                request.setValue($1, forHTTPHeaderField: $0)
            }
        }
        
        
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
             
                ////////////
                let bodyStr = String(data: data, encoding: .utf8) ?? "no body"
                    print("❌ HTTP \((response as? HTTPURLResponse)?.statusCode ?? -1): \(bodyStr)")
                
                //////////////

                return.Failed(msg: ApiError.UnknownError)
            }
            
        
            return .Success(data: try {
                let decoder = JSONDecoder()
                decoder.dateDecodingStrategy = .iso8601
                
                /* BOOM 💥 HERE IS THE IISUES THAT NEEDED THE DECODING STRATEY
                                                         
                                                        ISO 8601 is a standard date/time string format — that's what //NewsAPI (and most JSON APIs) uses for dates.

                                                         Format looks like:

                                                         2026-08-31T10:15:00Z
                                                         
                                                         
                 **/
                return try decoder.decode(R.self, from: data)
            }())
            
        }catch {
            print ("error here 11111")
            return .Failed(msg: ApiError.UnknownError)
        }
        
        
    }



    }



    


enum ApiType : Hashable {
    case GET,
    POST,
    PUT,
    DELETE
}

enum ApiError : Error {
    case InvalidURL,
         NoInternet,
    UnknownError
    
}
