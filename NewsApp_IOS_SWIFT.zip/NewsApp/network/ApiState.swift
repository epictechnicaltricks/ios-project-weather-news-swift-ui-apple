//
//  ApiState.swift
//  NewsApp
//
//  Created by Shubhamjit on 28/08/26.
//	

enum ApiState <V> {
    case Idle
    case Laoding
    case Success(data : V)
    case Failed(msg : ApiError)
}
