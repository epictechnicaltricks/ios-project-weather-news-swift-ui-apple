//
//  NewsImpl.swift
//  NewsApp
//
//  Created by Shubhamjit on 31/08/26.
//

class NewsImpl : NewsRepo {
    
    func findNews(query: String) async throws -> ApiState<NewsResponse> {
        return await ApiClient.shared.call(apiType: ApiType.GET, body: query)
    }
    
    func getTrendingNews() async throws -> ApiState<NewsResponse> {
        return await ApiClient.shared.call(apiType: ApiType.GET)
        // here i am stuck used try but insted only wait will we fine no need erro hamding ere 
    }
    
}
