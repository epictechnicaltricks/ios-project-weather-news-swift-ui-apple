//
//  BodyNews.swift
//  NewsApp
//
//  Created by Shubhamjit on 31/08/26.
//


struct BodyNews : Codable {
    let countryCode : String
}
