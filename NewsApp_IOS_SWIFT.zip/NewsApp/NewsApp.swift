//
//  NewsAppApp.swift
//  NewsApp
//
//  Created by Shubhamjit on 28/08/26.
//

import SwiftUI

@main
struct News: App {
    var body: some Scene {
        WindowGroup {
            MainScreen()
        }
    }
}
